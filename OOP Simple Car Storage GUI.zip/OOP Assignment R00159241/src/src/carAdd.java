package src;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class carAdd extends CarDatabase{
	//CarDatabase cars = new CarDatabase();
	public void start(Stage addingCar) {
		AnchorPane anchor = new AnchorPane();
		addingCar.setTitle("Add A Car To The Database");
		Scene addScene = new Scene(anchor, 400, 380);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox makeBox = new HBox();
		HBox modelBox = new HBox();
		HBox regBox = new HBox();
		HBox milageBox = new HBox();
		HBox yearBox = new HBox();
		
		Label makeLabel = new Label("Make : ");
		Label modelLabel = new Label("Model : ");
		Label regLabel = new Label("Registration : ");
		Label milageLabel = new Label("Milage : ");
		Label yearLabel = new Label("Year : ");
		
		TextField makeField = new TextField();
		TextField modelField = new TextField();
		TextField regField = new TextField();
		TextField milageField = new TextField();
		TextField yearField = new TextField();
		
		makeBox.getChildren().addAll(makeLabel, makeField);
		makeBox.setPadding(new Insets(20, 0, 0, 60));
		
		modelBox.getChildren().addAll(modelLabel, modelField);
		modelBox.setPadding(new Insets(0, 0, 0, 53));

		regBox.getChildren().addAll(regLabel, regField);
		regBox.setPadding(new Insets(0, 0, 0, 17));

		milageBox.getChildren().addAll(milageLabel, milageField);
		milageBox.setPadding(new Insets(0, 0, 0, 53));

		yearBox.getChildren().addAll(yearLabel, yearField);
		yearBox.setPadding(new Insets(0, 0, 0, 69));

		
		Button submit = new Button("  Submit  ");
		submit.setPadding(new Insets(20, 20, 20, 20));
		submit.setStyle("-fx-font-weight: bold");
		
		
		submit.setOnAction(e -> {
			String make = makeField.getText();
			String model = modelField.getText();
			Integer reg = Integer.parseInt(regField.getText());
			Integer year = Integer.parseInt(yearField.getText());
			Integer milage = Integer.parseInt(milageField.getText());
			
			Car car = new Car(make, model, reg, milage, year);
			addCar(car);
			
			Alert success = new Alert(AlertType.INFORMATION);
        	success.setHeaderText(null);
        	success.setTitle("Success");
        	success.setContentText("Car Successfully Added");
        	success.showAndWait();
        	
        	addingCar.close();
			
		});
		
		contents.getChildren().addAll(makeBox, modelBox, regBox, milageBox, yearBox, submit);
		
		contents.setSpacing(20);
		contents.setAlignment(Pos.BASELINE_CENTER);
		border.setStyle("-fx-background-color: #CC0000");
		border.setCenter(contents);
		border.prefHeightProperty().bind(addingCar.heightProperty());
		border.prefWidthProperty().bind(addingCar.widthProperty());
		anchor.getChildren().add(border);
		addingCar.setScene(addScene);
		addingCar.show();
	}
}
