package src;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class removeCar extends CarDatabase{
	public void start(Stage removeCar) {
		AnchorPane anchor = new AnchorPane();
		removeCar.setTitle("Remove A Car From The Database");
		Scene removeScene = new Scene(anchor, 450, 200);
		BorderPane border = new BorderPane();
		border.setStyle("-fx-background-color: #CC0000");
		
		
		VBox vlayout = new VBox();
		vlayout.setSpacing(30);
		
		HBox hlayout = new HBox();
		hlayout.setSpacing(20);
		hlayout.setAlignment(Pos.BASELINE_CENTER);
		hlayout.setPadding(new Insets(20,0,0,0));
		
		Label inputLabel = new Label("Enter Car Registration : ");
		TextField input = new TextField();
		hlayout.getChildren().addAll(inputLabel, input);
		
		Button submit = new Button("Submit");
		submit.setPadding(new Insets(20, 20, 20, 20));
		submit.setStyle("-fx-font-weight: bold;");
		
		vlayout.getChildren().addAll(hlayout, submit);
		
		submit.setOnAction(e -> {
			
			Integer reg = Integer.parseInt(input.getText());
			removeCar(reg);
			//printCars();
				Alert success = new Alert(AlertType.INFORMATION);
	        	success.setHeaderText(null);
	        	success.setTitle("Complete");
	        	success.setContentText("Operation Complete. Refer To Console");
	        	success.showAndWait();	
			
	        	removeCar.close();
	
        });
		vlayout.setAlignment(Pos.BASELINE_CENTER);
		
		border.setCenter(vlayout);
		border.prefHeightProperty().bind(removeCar.heightProperty());
		border.prefWidthProperty().bind(removeCar.widthProperty());
		anchor.getChildren().add(border);
		removeCar.setScene(removeScene);
		removeCar.show();
}
}