package src;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
	public void start(Stage home) {
		carAdd add = new carAdd();
		removeCar remove = new removeCar();
		carSort sort = new carSort();

		home.setTitle("Car Database");
		AnchorPane root = new AnchorPane();
		Scene mainScreen = new Scene(root, 700, 400);
		BorderPane borderPane = new BorderPane();
		
		
		VBox format = new VBox();
		format.setPadding(new Insets(10, 0, 0, 0));
		format.setSpacing(30);
		format.setAlignment(Pos.BASELINE_CENTER);
		borderPane.setStyle("-fx-background-color: #CC0000;");
		
		Button addButton = new Button("  Add Car To Database  ");
		addButton.setPadding(new Insets(20, 20, 20, 20));
		addButton.setStyle("-fx-font-weight: bold; -fx-font-size: 20px;");
		
		Button removeButton = new Button("Remove Car From Database");
		removeButton.setPadding(new Insets(20, 20, 20, 20));
		removeButton.setStyle("-fx-font-weight: bold; -fx-font-size: 20px;");
		
		Button listButton = new Button("Open Report Menu");
		listButton.setPadding(new Insets(20, 20, 20, 20));
		listButton.setStyle("-fx-font-weight: bold; -fx-font-size: 20px;");
		
		Button end = new Button("Close");
		/*Label output = new Label("Test");
		output.setPadding(new Insets(50, 0, 100, 300));
		output.setStyle("-fx-font-weight: bold; -fx-font-size: 35px;");
*/
		
		addButton.setOnAction(e -> {
			Stage addingCar = new Stage();
			add.start(addingCar);
		});
		
		removeButton.setOnAction(e -> {
			Stage removeCar = new Stage();
			remove.start(removeCar);
		});
		
		listButton.setOnAction(e -> {
			Stage sortMenu = new Stage();
			sort.start(sortMenu);
		});
		
		end.setOnAction(e -> {
			writeToFile write = new writeToFile();
			home.close();
		});
		format.getChildren().addAll(addButton, removeButton, listButton, end);
		borderPane.setCenter(format);
		//borderPane.setBottom(output);
		borderPane.prefHeightProperty().bind(home.heightProperty());
		borderPane.prefWidthProperty().bind(home.widthProperty());
		root.getChildren().add(borderPane);
		home.setScene(mainScreen);
		home.show();
	}
	readCarsFromFile reader = new readCarsFromFile();
	
	public static void main(String[] args) {
		/*CarDatabase cars = new CarDatabase();
		Car c1 = new Car("Merc", "f", 171, 2,2);
		Car c2 = new Car("Benz", "e", 161, 2, 2);
		
		cars.addCar(c1);
		cars.addCar(c2);*/
		
	//	cars.removeCar(161);
		Application.launch(args);

	}
}
