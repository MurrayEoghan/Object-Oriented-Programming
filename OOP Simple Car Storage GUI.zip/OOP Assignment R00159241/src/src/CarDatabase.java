package src;
import java.util.ArrayList;
import java.util.List;

public class CarDatabase {
	public static List<Car> carDatabase = new ArrayList<Car>();
	int numCars;
	/*public CarDatabase() {
		carDatabase = new ArrayList<Car>();
		this.numCars = 0;
	}*/
	
	public boolean isEmpty() {
		if(carDatabase.size() == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void addCar(Car c) {
		carDatabase.add(c);
		numCars++;
		System.out.println("Number of cars : "+getSize());
		//printCars();
		}
	
	
		
	
	public void removeCar(int reg) {
		boolean res = true;
		for(int i = 0; i < getSize(); i++) {
			if(carDatabase.get(i).getReg() == reg) {
				carDatabase.remove(i);
				numCars--;
				res = true;
				break;
				
			}
			else {
				System.out.println("Car doesnt exist.");
				res = false;
			}
		}
	}
	
	
	
	public void printCars() {
		for(Car c : carDatabase) {
			System.out.println(c.toString());
		}
		if(carDatabase.isEmpty()) {
			System.out.println("Database empty");
		}
	}
	
	public void sortCars() {
		
	}

	
	public int getSize() {
		return carDatabase.size();
	}
	
}
