package src;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
public class readCarsFromFile extends CarDatabase{
	
	{
	try {

		InputStream file = getClass().getResourceAsStream("cars.txt");
		BufferedReader scan = new BufferedReader(new InputStreamReader(file));
		while(scan.ready()) {
		
		
			String make = scan.readLine();
			String model = scan.readLine();
			Integer reg = Integer.parseInt(scan.readLine());
			Integer milage = Integer.parseInt(scan.readLine());
			Integer year = Integer.parseInt(scan.readLine());
			
			Car car = new Car(make, model, reg, milage, year);
			addCar(car);
			
		}
		scan.close();

	}

	catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}

}
	

}
