package src;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class writeToFile extends CarDatabase{
	{
	try {
		File cars = new File("cars.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(cars));
		
		for(Car c : carDatabase) {
			
			out.write(c.getMake()+"\n");
			out.write(c.getModel()+"\n");
			out.write(c.getReg()+"\n");
			out.write(c.getMilage()+"\n");
			out.write(c.getYear()+"\n");
		}
		out.close();
	}
	catch(FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
}
}