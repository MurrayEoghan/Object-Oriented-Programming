package src;
import java.util.Comparator;
import java.util.List;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class carSort extends CarDatabase{

	
	public void start(Stage sortMenu) {
		AnchorPane anchor = new AnchorPane();
		sortMenu.setTitle("Choose An Option");
		Scene listMenu = new Scene(anchor, 350, 300);
		BorderPane border = new BorderPane();
		border.setStyle("-fx-background-color: #CC0000;");
		
		VBox menu = new VBox();
		menu.setSpacing(30);
		
		Button normalList = new Button("1. Natural List");
		normalList.setPadding(new Insets(20,20,20,20));
		normalList.setStyle("-fx-font-weight: bold;");
		

		normalList.setOnAction(e -> {
			
			//CREATING NATURAL LIST DISPLAY
			
			Stage displayList = new Stage();
			displayList.setTitle("List Display");
			AnchorPane a1 = new AnchorPane();
			Scene display = new Scene(a1, 620, 450);
			BorderPane b1 = new BorderPane();
			
			TableView table = new TableView();
			TableColumn<String, Car> col1 = new TableColumn("Make");
			col1.setCellValueFactory(new PropertyValueFactory<>("make"));
			
			TableColumn<String, Car> col2 = new TableColumn<String, Car>("Model");
			col2.setCellValueFactory(new PropertyValueFactory<>("model"));
			
			TableColumn<String, Car> col3 = new TableColumn("Registration");
			col3.setCellValueFactory(new PropertyValueFactory<>("reg"));
			
			TableColumn<String, Car> col4 = new TableColumn("Milage");
			col4.setCellValueFactory(new PropertyValueFactory<>("milage"));
			
			TableColumn<String, Car> col5 = new TableColumn("Year");
			col5.setCellValueFactory(new PropertyValueFactory<>("year"));
			
			table.getColumns().setAll(col1, col2, col3, col4, col5);

			for(Car c : carDatabase) {
				table.getItems().add(c);
			}
			
			VBox layout = new VBox();
			layout.getChildren().add(table);
			b1.setCenter(layout);
			b1.prefHeightProperty().bind(displayList.heightProperty());
			b1.prefWidthProperty().bind(displayList.widthProperty());
			a1.getChildren().add(b1);
			displayList.setScene(display);
			displayList.show();
			sortMenu.close();
		});
		
		Button yearList = new Button("2. Ordered by Milage");
		yearList.setPadding(new Insets(20,20,20,20));
		yearList.setStyle("-fx-font-weight: bold;");
		
		yearList.setOnAction(e -> {
			
			//CREATING MILAGE ORDERED LIST
			
			Stage displayMilageList = new Stage();
			displayMilageList.setTitle("Milage List Display");
			AnchorPane a2 = new AnchorPane();
			Scene display = new Scene(a2, 620, 450);
			BorderPane b2 = new BorderPane();
			

	      //  list.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

			List<Car> res = carDatabase;
			
				res.sort(Comparator.comparing(Car::getMilage));
			
				TableView table = new TableView();
				TableColumn<String, Car> col1 = new TableColumn("Make");
				col1.setCellValueFactory(new PropertyValueFactory<>("make"));
				
				TableColumn<String, Car> col2 = new TableColumn<String, Car>("Model");
				col2.setCellValueFactory(new PropertyValueFactory<>("model"));
				
				TableColumn<String, Car> col3 = new TableColumn("Registration");
				col3.setCellValueFactory(new PropertyValueFactory<>("reg"));
				
				TableColumn<String, Car> col4 = new TableColumn("Milage");
				col4.setCellValueFactory(new PropertyValueFactory<>("milage"));
				
				TableColumn<String, Car> col5 = new TableColumn("Year");
				col5.setCellValueFactory(new PropertyValueFactory<>("year"));
				
				table.getColumns().setAll(col1, col2, col3, col4, col5);
			for(Car c : res) {
				table.getItems().add(c);
			}
			
			VBox layout = new VBox();
			layout.getChildren().addAll(table);
			b2.setCenter(layout);
			b2.prefHeightProperty().bind(displayMilageList.heightProperty());
			b2.prefWidthProperty().bind(displayMilageList.widthProperty());
			a2.getChildren().add(b2);
			displayMilageList.setScene(display);
			displayMilageList.show();
			sortMenu.close();

		});
		
		Button milageList = new Button("3. Ordered by Year");
		milageList.setPadding(new Insets(20,20,20,20));
		milageList.setStyle("-fx-font-weight: bold;");
		
		milageList.setOnAction(e -> {
			
			// CREATING YEAR ORDERED LIST
			
			Stage displayYearList = new Stage();
			displayYearList.setTitle("Year List Display");
			AnchorPane a3 = new AnchorPane();
			Scene display = new Scene(a3, 620, 450);
			BorderPane b3 = new BorderPane();
			
	      //  list.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
			List<Car> res = carDatabase;
			
			res.sort(Comparator.comparing(Car::getYear));
			
			TableView table = new TableView();
			TableColumn<String, Car> col1 = new TableColumn("Make");
			col1.setCellValueFactory(new PropertyValueFactory<>("make"));
			
			TableColumn<String, Car> col2 = new TableColumn<String, Car>("Model");
			col2.setCellValueFactory(new PropertyValueFactory<>("model"));
			
			TableColumn<String, Car> col3 = new TableColumn("Registration");
			col3.setCellValueFactory(new PropertyValueFactory<>("reg"));
			
			TableColumn<String, Car> col4 = new TableColumn("Milage");
			col4.setCellValueFactory(new PropertyValueFactory<>("milage"));
			
			TableColumn<String, Car> col5 = new TableColumn("Year");
			col5.setCellValueFactory(new PropertyValueFactory<>("year"));
			
			table.getColumns().setAll(col1, col2, col3, col4, col5);
			for(Car c : res) {
				table.getItems().add(c);
			}
			
			VBox layout = new VBox();
			layout.getChildren().addAll(table);
			b3.setCenter(layout);
			b3.prefHeightProperty().bind(displayYearList.heightProperty());
			b3.prefWidthProperty().bind(displayYearList.widthProperty());
			a3.getChildren().add(b3);
			displayYearList.setScene(display);
			displayYearList.show();
			sortMenu.close();

		});
		
		menu.getChildren().addAll(normalList,yearList,milageList);
		menu.setAlignment(Pos.BASELINE_CENTER);
		
		border.setCenter(menu);
		border.prefHeightProperty().bind(sortMenu.heightProperty());
		border.prefWidthProperty().bind(sortMenu.widthProperty());
		anchor.getChildren().add(border);
		sortMenu.setScene(listMenu);
		sortMenu.show();
	}
	


	
	
	
}
