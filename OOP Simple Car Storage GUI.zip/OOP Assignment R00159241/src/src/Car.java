package src;
public class Car {
	private String make; 
	private String model;
	private int reg;
	private int milage;
	private int year;
	
	public Car(String make, String model, int reg, int milage, int year) {
		this.make = make;
		this.model = model;
		this.reg = reg;
		this.milage = milage;
		this.year = year;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getReg() {
		return reg;
	}

	public void setReg(int reg) {
		this.reg = reg;
	}

	public int getMilage() {
		return milage;
	}

	public void setMilage(int milage) {
		this.milage = milage;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "Make : "+make+"\nModel : "+model+"\nRegistration : "+reg+"\nMilage : "+milage+"\nYear : "+year+"\n";
	}
	
	
}

