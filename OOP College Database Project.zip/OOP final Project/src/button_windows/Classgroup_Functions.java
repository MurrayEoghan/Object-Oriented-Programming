package button_windows;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import school.ClassGroup;
import school.School;

public class Classgroup_Functions {
	public void addCG(Stage addCG) {
		AnchorPane root = new AnchorPane();
		addCG.setTitle("Add Class Group");
		Scene addCGScene = new Scene(root, 330, 150);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox layout = new HBox();
		
		TextField input = new TextField();
		Label classID = new Label("Class ID :\nLimit 2 Digits ");
		Button submit = new Button("Submit");
		

		
		layout.getChildren().addAll(classID, input);
		contents.getChildren().addAll(layout, submit);
		
		contents.setAlignment(Pos.BASELINE_CENTER);
		contents.setPadding(new Insets(30, 0, 0, 30));
		contents.setSpacing(10);
		try {
		       Class.forName("com.mysql.cj.jdbc.Driver").newInstance();      
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school_system?user=root&password=pass123&useSSL=false&serverTimezone=GMT" );
				submit.setOnAction(e -> {
					Integer id = Integer.parseInt(input.getText());
					
					School s = new School("Cork Institute of Technology");
					ClassGroup cg = new ClassGroup(id);
					s.addClass(cg, con);
					addCG.close();
				});
		
		}catch(SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		border.setCenter(contents);
		border.prefWidthProperty().bind(addCG.widthProperty());
		border.prefHeightProperty().bind(addCG.heightProperty());
		root.getChildren().add(border);
		addCG.setScene(addCGScene);
		addCG.show();
		
	}

	public void removeCG(Stage removeCG) {
		AnchorPane root = new AnchorPane();
		removeCG.setTitle("Remove Class Group");
		Scene removeCGScene = new Scene(root, 330, 150);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox layout = new HBox();
		
		TextField input = new TextField();
		Label classID = new Label("Class ID :\nLimit 2 Digits ");
		Button submit = new Button("Submit");
		

		
		layout.getChildren().addAll(classID, input);
		contents.getChildren().addAll(layout, submit);
		
		contents.setAlignment(Pos.BASELINE_CENTER);
		contents.setPadding(new Insets(30, 0, 0, 30));
		contents.setSpacing(10);
		try {
		       Class.forName("com.mysql.cj.jdbc.Driver").newInstance();      
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school_system?user=root&password=pass123&useSSL=false&serverTimezone=GMT" );
				submit.setOnAction(e -> {
					Integer id = Integer.parseInt(input.getText());
					
					School s = new School();
					ClassGroup cg = new ClassGroup(id);
					s.removeClass(cg, con);
					System.out.println("Class Removed");
					removeCG.close();
				});
		
		}catch(SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		border.setCenter(contents);
		border.prefWidthProperty().bind(removeCG.widthProperty());
		border.prefHeightProperty().bind(removeCG.heightProperty());
		root.getChildren().add(border);
		removeCG.setScene(removeCGScene);
		removeCG.show();
		
		
	}
}

