package person;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.scene.control.TextArea;

public class Teacher extends Person{
	private String qualification;
	private int teacherID;
	public Teacher() {
	}
	
	public Teacher(int id, String fname, String mname, String lname, String email, int phone, String qualification) {
		setfName(fname);
		setmName(mname);
		setlName(lname);
		setEmail(email);
		setPhone(phone);
		this.qualification = qualification;
		this.teacherID = id;
	}
	
	public Teacher(String fname, String lname, String email, int phone, String qualification) {
		setfName(fname);
		setlName(lname);
		setEmail(email);
		setPhone(phone);
		this.qualification = qualification;
	}

	public void addTeacher(Connection con) {
		String query = "Insert into teacher(TeacherID, FirstName, MiddleName, LastName, Qualification, Email, Phone)"+" values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement insert = con.prepareStatement(query);
			insert.setInt(1, teacherID);
			insert.setString(2, getfName());
			insert.setString(3, getmName());
			insert.setString(4, getlName());
			insert.setString(5, qualification);
			insert.setString(6, getEmail());
			insert.setInt(7, getPhone());
			insert.execute();
			System.out.println("\nTeacher "+teacherID+" successfully added.\n");
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void removeTeacher(Connection con) {
		String query = "Delete From teacher Where TeacherID = ?";{
			try {
				PreparedStatement remove = con.prepareStatement(query);
				remove.setInt(1, teacherID);
				remove.execute();
				System.out.println("\nTeacher : "+teacherID+" removed successfully\n");
				
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public void printTeachers(Connection con, TextArea ta) {
		String query = "Select * From teacher Order By TeacherID;";
		try {
			Statement stmt = con.createStatement();
			ResultSet res = stmt.executeQuery(query);
			while(res.next()) {
				int id = res.getInt(1);
				String fname = res.getString(2);
				String mname = res.getString(3);
				String lname = res.getString(4);
				String qualification = res.getString(5);
				String email = res.getString(6);
				int phone = res.getInt(7);
				String val = "ID : "+id+"\nFirst Name : "+fname+"\nMiddle Name : "+mname+"\nLast Name : "+lname+"\nQualification : "+qualification+"\nEmail : "+email+"\nPhone : "+phone+"\n\n";
				ta.appendText(val);
			}
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public String getQualification() {
		return qualification;
	}

	public void setQualification(Connection con, String newQualification, int id) {
		
		String query = "Update teacher SET Qualification = ? Where TeacherID = ?";
		try {
			PreparedStatement update = con.prepareStatement(query);
			update.setString(1, newQualification);
			update.setInt(2, id);
			update.execute();
			System.out.println("Qualification of "+id+" changed to "+newQualification);
			this.qualification = newQualification;

		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	public int getTeacherID() {
		return teacherID;
	}

	public void setTeacherID(int teacherID) {
		this.teacherID = teacherID;
	}

	@Override
	public String toString() {
		return getfName()+" "+getmName()+" "+getlName()+" "+getEmail()+" "+getPhone()+" "+ qualification;
	}
	
}
