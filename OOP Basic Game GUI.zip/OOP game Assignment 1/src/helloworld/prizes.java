package helloworld;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
public class prizes {
	
	BufferedReader reader = null;
	public List<String> prizeArray = new ArrayList<String>();
	


	{
		try {
			
			File file = new File("C:\\Users\\eogha\\eclipse-workspace\\OOP game Assignment 1\\src\\helloworld\\prizes.txt");
			reader = new BufferedReader(new FileReader(file));
			String line;
			int i = 0;
			while((line = reader.readLine())!= null) {

				prizeArray.add(i, line);
				i++;
			}


			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			
			finally {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		
	}
	public List<String> getPrizes(){
		
		
		return prizeArray;
	}
	
	
}
