package helloworld;

public class lotto {

}
