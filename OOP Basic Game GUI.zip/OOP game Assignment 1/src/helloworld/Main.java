package helloworld;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.util.*;
public class Main extends Application {



	private int prizePoints = 0;
	// HI LO VARIABLES
	private int score = 0;
	private int highScore = 0;
	private int lives = 4;
	private int numberToGuess = randomInt();

	// LOTTO VARIABLES
	
	private int winningNums[] = new int[5];
	
	// CREATION OF THE GUI
	prizes prize = new prizes();
	List<String> prizes = prize.getPrizes();

    public void start(Stage primaryStage) {

        primaryStage.setTitle("Games");
        AnchorPane root = new AnchorPane();
        Scene scene = new Scene(root, 600, 350, Color.WHITE);
        // CREATING 3 TABS
        TabPane tabPane = new TabPane();

        BorderPane borderPane = new BorderPane();
        Tab tab1 = new Tab("Lotto");
        Tab tab2 = new Tab("Hi Lo");
        Tab tab3 = new Tab("Prizes");
        tabPane.getTabs().addAll(tab1, tab2, tab3);
        
        
        Label hiloPoints = new Label("Prize Points : "+prizePoints);
        hiloPoints.setPadding(new Insets(0,0,0,-15));
        Label redeemablePoints = new Label("Prize Points : "+prizePoints);
        redeemablePoints.setPadding(new Insets(-30,0,0,490));
        Label lottoPoints = new Label("Prize Points : "+prizePoints);
        lottoPoints.setPadding(new Insets(5, 0,0,-15));

        //PRIZES NODES
        Label prizeLabel = new Label("\t\tPrize \t\t\t\t\t Points Required");
        ListView<String> list = new ListView<>();
        Button selectPrize = new Button();			
        selectPrize.setText("Select");
        
        int counter = 0;
        String value = null;
        while(counter < prizes.size()) {
        value = prizes.get(counter);
        counter++;
        list.getItems().add(value);
        }
        
        list.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        VBox prizeVbox = new VBox();
        prizeVbox.getChildren().addAll(prizeLabel, list, selectPrize, redeemablePoints);
        tab3.setContent(prizeVbox);
        
        selectPrize.setOnAction(e ->{
            int topics = list.getSelectionModel().getSelectedIndex();
            
        	Alert won = new Alert(AlertType.INFORMATION);
        	won.setHeaderText(null);
        	won.setTitle("You Won!");
        	
        	Alert lost = new Alert(AlertType.INFORMATION);
        	lost.setHeaderText(null);
        	lost.setTitle("Not Enough Points");
        	lost.setContentText("You don't have enough points for that prize.");
        	
        	
        	
        	if(topics == 0 && prizePoints >= 4) {
        		prizePoints -= 4;
        		won.setContentText("You Won �100!");
        		won.showAndWait();
        	}
        	else if (topics == 1 && prizePoints >= 14) {
        		prizePoints -= 14;
        		won.setContentText("You Won �1000!");
        		won.showAndWait();
        	}
        	else if(topics == 2 && prizePoints >= 6) {
        		prizePoints -= 6;
        		won.setContentText("You won a trip to Donegal!");
        		won.showAndWait();
        	}
        	else if(topics == 3 && prizePoints >= 12) {
        		prizePoints -= 12;
        		won.setContentText("You won a trip to the Carribean!");
        		won.showAndWait();
        	}
        	else {
        		lost.showAndWait();
        	}
        	
			hiloPoints.setText("Prize Points : "+prizePoints);
			redeemablePoints.setText("Prize Points : "+prizePoints);
			lottoPoints.setText("Prize Points : "+prizePoints);
        });
        
        
        
        
        

        // LOTTO CREATE NEW NODES
        
        
        
        Button play = new Button("  PLAY  ");
        Label enterNums = new Label("Enter your Numbers (1 per box)\n-------------------------------------");
        enterNums.setPadding(new Insets(-300, 0,0, -80));
        enterNums.setStyle("-fx-font-weight: bold;");
        TextField num1 = new TextField();
        TextField num2 = new TextField();
        TextField num3 = new TextField();
        TextField num4 = new TextField();
        TextField num5 = new TextField();
        


        // HBOX FOR LOTTO ENTRY NUMBERS
        Label printWinNums = new Label("Winning Numbers : ");
       
        printWinNums.setStyle("-fx-font-weight: bold; -fx-font-size: 20px;");
        printWinNums.setPadding(new Insets(-100, 0, 0, -115));
        
        HBox lottoH = new HBox();
        
        lottoH.setPadding(new Insets(-120,100,0,-130));
        lottoH.getChildren().addAll(num1, num2, num3, num4, num5);
        
        // Generate the winning numbers
        winningNumGenerator();
        
        // LOTTO VBOX TO ADD NEW NODES
        VBox lotto = new VBox();
        lotto.setPadding(new Insets(190,25,25,270));
        lotto.setSpacing(10);
        lotto.setStyle("-fx-background-color: #7C4DFF;");
        lotto.getChildren().addAll(enterNums, lottoH, printWinNums ,play, hiloPoints, lottoPoints);
        tab1.setContent(lotto);
        
        //PLAY BUTTON AND LOTTO FUNCTIONALITY
        play.setOnAction(e -> {
            Integer val1 = Integer.parseInt(num1.getText());
            Integer val2 = Integer.parseInt(num2.getText());
            Integer val3 = Integer.parseInt(num3.getText());
            Integer val4 = Integer.parseInt(num4.getText());
            Integer val5 = Integer.parseInt(num5.getText());
        	if(val1 == winningNums[0] && val2 == winningNums[1] && val3 == winningNums[2] && val4 == winningNums[3] && val5 == winningNums[4]) {

        		System.out.println("You won. Reset to play again");
        		prizePoints+=5;
    			hiloPoints.setText("Prize Points : "+prizePoints);
    			redeemablePoints.setText("Prize Points : "+prizePoints);
    			lottoPoints.setText("Prize Points : "+prizePoints);
        		printWinNums.setText("Winning Numbers : "+winningNums[0]+"  "+winningNums[1]+"  "+winningNums[2]+"  "+winningNums[3]+"  "+winningNums[4]);
        	}
        	else {

        		System.out.println("You lost. Reset to play again");
        		printWinNums.setText("Winning Numbers : "+winningNums[0]+"  "+winningNums[1]+"  "+winningNums[2]+"  "+winningNums[3]+"  "+winningNums[4]);

        	}
        });
        root.getChildren().add(lotto);

        
        //    HI LO CREATING NODES
        Button guess = new Button(" Guess ");
        TextField numberEntry = new TextField();
        Label scoreLabel = new Label("Lives Left : "+lives);
        Label currentState = new Label("");
        Label highestScore = new Label("Wins in a Row : "+highScore);
        highestScore.setStyle("-fx-font-weight: bold;");
        highestScore.setPadding(new Insets(-40,0,0,-35));
        currentState.setStyle("-fx-margin: 0;");
        scoreLabel.setPadding(new Insets(-100, 0,0, -30));
        scoreLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 20px;");
        root.getChildren().addAll(guess);
        
        // HI LO VBOX TO ADD NEW NODES
        HBox text = new HBox();
        text.getChildren().add(numberEntry);
        text.setPadding(new Insets(0,0,0,-60));
        VBox hilo = new VBox();
        hilo.setPadding(new Insets(100, 20, 20, 270));
        hilo.setSpacing(10);
        hilo.setStyle("-fx-background-color: #FF8A80;");
        hilo.getChildren().addAll(scoreLabel, highestScore, text);
        hilo.getChildren().addAll(guess, currentState, hiloPoints);
        tab2.setContent(hilo);
        
        // HI LO GAME HI BUTTON FUNCTIONALITY

        guess.setOnAction(e -> {
            Integer entry = Integer.parseInt(numberEntry.getText());

        		if(numberToGuess == entry) {

        			lives = 4;
        			scoreLabel.setText("Lives Left : "+lives);
        			currentState.setText("You Did It! 2+ points");
        			prizePoints += 2;
        			highScore +=1;
        			highestScore.setText("Wins in a Row : "+highScore);
        			hiloPoints.setText("Prize Points : "+prizePoints);
        			redeemablePoints.setText("Prize Points : "+prizePoints);
        			lottoPoints.setText("Prize Points : "+prizePoints);
        			score +=1;
        	        currentState.setPadding(new Insets(20,0,0,-30));
        			numberToGuess = randomInt();
        		//	System.out.println(numberToGuess);					UNCOMMENT THIS LINE TO SEE NEXT ROUNDS NUMBER TO GAIN POINTS FOR TESTING
        			
        		}
        		else if(numberToGuess >= entry) {
        			lives-=1;
        			currentState.setText("Too Low!");
        			scoreLabel.setText("Lives Left : "+lives);
        			System.out.println(numberToGuess);
        	        currentState.setPadding(new Insets(20,0,0,0));

        	}
        		else {

        			lives-=1;
        			scoreLabel.setText("Lives Left : "+lives);
        			currentState.setText("Too high!");
        	        currentState.setPadding(new Insets(20,0,0,0));

        			System.out.println(numberToGuess);
        		}
    			
    			if(lives == 0) {
    				highScore = 0;
    				lives =4;
    				currentState.setText("You Lost :(");
    				System.out.println("Game Reset.");
    			}
    			if(score == 5) {
    				prizePoints += 3;
    				currentState.setText("You wont 5 in a row! here's 3 bonus points!");
    				hiloPoints.setText("Prize Points : "+prizePoints);
    				
    			}
        });
        
        // HI LO GAME LO BUTTON FUNCTIONALITY
        

        
        
        borderPane.prefHeightProperty().bind(scene.heightProperty());
        borderPane.prefWidthProperty().bind(scene.widthProperty());
        borderPane.setCenter(tabPane);
        root.getChildren().add(borderPane);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    

    
    // Random number generators

    public int randomInt() {
		Random random = new Random();
		int res = random.nextInt(50);
		return res;
    }
    
    public void winningNumGenerator() {
    	for(int i = 0; i < 5; i++) {
    		winningNums[i] += randomInt();
    	}
    }

    
    
public static void main(String[] args) {
    Application.launch(args);
}}
