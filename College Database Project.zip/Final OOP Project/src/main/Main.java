package main;

import java.sql.*;
import java.sql.DriverManager;

import button_windows.Classgroup_Functions;
import button_windows.TeacherFunctions;
import button_windows.student_functions;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import javafx.stage.Stage;
import person.*;
import school.*;
public class Main extends Application{

	
	@Override
	public void start(Stage primaryStage) throws Exception {
		Teacher t = new Teacher();
		Student s = new Student();
		ClassGroup cg = new ClassGroup();
		School school = new School();
		try {
		       Class.forName("com.mysql.cj.jdbc.Driver").newInstance();      
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school_system?user=root&password=pass123&useSSL=false&serverTimezone=GMT" );
		       System.out.println ("Database connection established\n");

		       // FX Begins here 
		       
		       primaryStage.setTitle("College Database Management System");
		       AnchorPane root = new AnchorPane();
		       Scene main = new Scene(root, 950, 500);
		       BorderPane borderPane = new BorderPane();
		       
		       
		       HBox layout = new HBox();
		       
		       
		       // BUTTONS, DISPLAY AND ALIGNMENT 
		       
		       VBox buttonLayout = new VBox();
		       VBox printButtonLayout = new VBox();
		       
		       Label functions = new Label("Functions");
		       Label print = new Label("Prints");
		       
		       functions.setStyle("-fx-font-weight: bold; -fx-font-size: 20px;");
		       functions.setPadding(new Insets(0, 0, -20, 0));
		       
		       print.setStyle("-fx-font-weight: bold; -fx-font-size: 20px;");
		       print.setPadding(new Insets(0, 0, -50, 0));
		       
		       Button addStudent = new Button("Add Student");
		       Button removeStudent = new Button("Remove Student");
		       Button addCG = new Button("Add Class Group");
		       Button removeCG = new Button("Remove Class Group");
		       Button addTeacher = new Button("Add Teacher");
		       Button editGrade = new Button("Modify Grades");
		       Button editTeacher = new Button("Modify Teacher");
		       
		       Button printStudents = new Button("Print Student Details");
		       Button printGrades = new Button("Print Student Grades");
		       Button printTeachers = new Button("Print Teacher Details");
		       Button classes = new Button("Print Class Details");
		       
		       buttonLayout.getChildren().addAll(functions, addStudent, removeStudent, addCG, removeCG, addTeacher, editGrade, editTeacher);
		       printButtonLayout.getChildren().addAll(print, printStudents, printGrades, printTeachers, classes);
		       
		       buttonLayout.setAlignment(Pos.BASELINE_CENTER);
		       buttonLayout.setPadding(new Insets(50, 250, 0, 0));
		       buttonLayout.setSpacing(20);
		       
		       printButtonLayout.setAlignment(Pos.BASELINE_CENTER);
		       printButtonLayout.setPadding(new Insets(100, 140, 0, -140));
		       printButtonLayout.setSpacing(25);
		       
		       TextArea display = new TextArea();
		       display.setEditable(false);
		       display.setPrefWidth(300);

		      
		       
		       
		       layout.getChildren().addAll(buttonLayout ,printButtonLayout, display);
		       layout.setAlignment(Pos.CENTER_RIGHT);

		       
		       
		       //BUTTON FUNCTIONALITY 
		       student_functions sf = new student_functions();
		       Classgroup_Functions cf = new Classgroup_Functions();
		       TeacherFunctions tf = new TeacherFunctions();
		       
		       addStudent.setOnAction(e -> {
		    	   Stage addStudentWindow = new Stage();
		    	   sf.start(addStudentWindow);
		       });
		       
		       
		       removeStudent.setOnAction(e -> {
		    	   Stage removeStudentWindow = new Stage();
		    	   sf.removeStudent(removeStudentWindow);
		       });
		       
		       addCG.setOnAction(e -> {
		    	   Stage addCGWindow = new Stage();
		    	   cf.addCG(addCGWindow);
		       });
		       
		       removeCG.setOnAction(e -> {
		    	   Stage removeCGWindow = new Stage();
		    	   cf.removeCG(removeCGWindow);
		       });
		       
		       addTeacher.setOnAction(e -> {
		    	   Stage addTeacherWindow = new Stage();
		    	   tf.addTeacher(addTeacherWindow);
		       });
		       
		       editGrade.setOnAction(e -> {
		    	   Stage changeGWindow = new Stage();
		    	   sf.changeGrade(changeGWindow);
		       });
		       
		       editTeacher.setOnAction(e -> {
		    	   Stage changeQWindow = new Stage();
		    	   tf.changeQualification(changeQWindow);
		       });
		       printGrades.setOnAction(e -> {
		    	   display.clear();
			       s.printMG(con, display);
		       });
		       printTeachers.setOnAction(e -> {
		    	   display.clear();
		    	   t.printTeachers(con, display);
		       });
		       printStudents.setOnAction(e -> {
		    	   display.clear();
		    	   cg.printStudent(con, display);
		       });
		       classes.setOnAction(e -> {
		    	   display.clear();
		    	   school.printClasses(con, display);
		       });
		       
		       borderPane.setCenter(layout);
		       borderPane.prefWidthProperty().bind(primaryStage.widthProperty());
		       borderPane.prefHeightProperty().bind(primaryStage.heightProperty());
		       root.getChildren().add(borderPane);
		       primaryStage.setScene(main);
		       primaryStage.show();
		       
		       
		       
		}catch (Exception ex) {
		    System.out.println("SQLException: " + ex.getMessage());    
		};
	}

	
	public static void main(String[] args) {


		Application.launch(args);
		


	}



}
