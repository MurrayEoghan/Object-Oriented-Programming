package school;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javafx.scene.control.TextArea;

public class School {
	private String name;
	private static ArrayList<ClassGroup> classes = new ArrayList<ClassGroup>();
	
	public School() {
	}
	
	public School(String name) {
		this.name = name;
	}
	
	public void addClass(ClassGroup cg, Connection con) {
		classes.add(cg);
		try {
			String query = "Insert into School (School_name, ClassID) "+"values (?, ?)";
			PreparedStatement insert = con.prepareStatement(query);
			insert.setString(1, name);
			insert.setInt(2, cg.getClassID());
			insert.execute();
			System.out.println("Class Group "+cg.getClassID()+" Added to "+name);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public void removeClass(ClassGroup cg, Connection con) {

		try {
			String querySchool = "delete from school where ClassID = ?";
			String queryClass = "delete from classgroup where ClassID = ?";
			String queryStudent = "delete from student where ClassID = ?";
			PreparedStatement deleteClass = con.prepareStatement(queryClass);
			PreparedStatement deleteSchool = con.prepareStatement(querySchool);
			PreparedStatement deleteStudent = con.prepareStatement(queryStudent);
			deleteSchool.setInt(1, cg.getClassID());
			deleteClass.setInt(1, cg.getClassID());
			deleteStudent.setInt(1, cg.getClassID());
			deleteSchool.execute();
			deleteClass.execute();
			deleteStudent.execute();
			
			String updateStudentQuery = "update student set ClassID = null where ClassID = ?";
			PreparedStatement update = con.prepareStatement(updateStudentQuery);
			update.setInt(1, cg.getClassID());
			update.execute();
			
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	}
	
	public void printClasses(Connection con, TextArea ta) {
		String val = " ";
		try {
			Statement stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("Select * From classgroup Order By ClassID;");
			while(res.next()) {
				int classID = res.getInt("ClassID");
				int studentID = res.getInt("StudentID");
				String fname = res.getString("FirstName");
				String lname = res.getString("LastName");
				val = "Class ID : "+classID+"\nStudent ID : "+studentID+"\nFirst Name : "+fname+"\nLast Name : "+lname+"\n\n";
				ta.appendText(val);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
