package school;

import java.util.ArrayList;
import java.util.Random;

import javafx.scene.control.TextArea;

import java.sql.*;
import person.Student;

public class ClassGroup extends School{
	private int classID;
	private int noStudents;
	private static ArrayList<Student> classGroup = new ArrayList<Student>();
	
	
	
	public ClassGroup() {
		this.classID = randomInt();
	}
	
	public ClassGroup(int id) {
		this.classID = id;
	}
	
    public int randomInt() {
		Random random = new Random();
		int res = random.nextInt(20);
		return res;
    }
	
	public void addStudent(Student s, Connection con) {
		noStudents++;
		String query = "Insert into student(StudentID, FirstName, MiddleName, LastName, Email, Phone, ClassID, DOB)"+" values(?,?,?,?,?,?,?,?)";
		String query2 = "Insert into classgroup(ClassID, StudentID, FirstName, LastName)"+" values(?,?,?,?)";
		try {
			PreparedStatement add = con.prepareStatement(query);
			add.setInt(1, s.getStudentID());
			add.setString(2, s.getfName());
			add.setString(3, s.getmName());
			add.setString(4, s.getlName());
			add.setString(5, s.getEmail());
			add.setInt(6, s.getPhone());
			add.setInt(7, classID);
			add.setString(8, s.getDob());
			add.execute();
			
			
			PreparedStatement addToClass = con.prepareStatement(query2);
			addToClass.setInt(1, classID);
			addToClass.setInt(2, s.getStudentID());
			addToClass.setString(3, s.getfName());
			addToClass.setString(4, s.getlName());
			addToClass.execute();
			
			System.out.println("Student successfully added.");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		
		System.out.println(s.getfName()+" added successfully to class "+classID);
		//PreparedStatement preparedStatement = connection.preparedStatement();
	}
	
	public void removeStudent(int id, Connection con) {
		String query = "Delete from student where StudentID = ?";
		String query2 = "Delete from classgroup where StudentID = ?";
		String query3 = "Delete from grades where StudentID = ?";
		try {
			PreparedStatement student = con.prepareStatement(query);
			PreparedStatement classDel = con.prepareStatement(query2);
			PreparedStatement gradeDel = con.prepareStatement(query3);
			
			student.setInt(1, id);
			student.execute();
			
			classDel.setInt(1, id);
			classDel.execute();
			
			gradeDel.setInt(1, id);
			gradeDel.execute();
			
			System.out.println("Student Removed Successfully");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void printStudent(Connection con, TextArea ta) {
		String val = " ";
		try {
			Statement stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("Select * From student Order By StudentID");
			
			while(res.next()) {
				int id = res.getInt("StudentID");
				String fname = res.getString("FirstName");
				String mname = res.getString("MiddleName");
				String lname = res.getString("LastName");
				String email = res.getString("Email");
				int phone = res.getInt("Phone");
				String dob = res.getString("DOB");
				int classID = res.getInt("ClassID");
				
				val = "Student ID : "+id+"\nFirst Name : "+fname+"\nMiddle Name : "+mname+"\nLast Name : "+lname+"\nEmail : "+email+"\nPhone : "+phone+"\nDOB : "+dob+"\nClass ID : "+classID+"\n\n";
				ta.appendText(val);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public int getClassID() {
		return classID;
	}

	public void setClassID(int classID) {
		this.classID = classID;
	}

	public int getNoStudents() {
		return noStudents;
	}

	public void setNoStudents(int noStudents) {
		this.noStudents = noStudents;
	}

	public static ArrayList<Student> getClassGroup() {
		return classGroup;
	}

	public static void setClassGroup(ArrayList<Student> classGroup) {
		ClassGroup.classGroup = classGroup;
	}

	@Override
	public String toString() {
		return "ClassGroup [classID=" + classID + ", noStudents=" + noStudents + "]";
	}
	
}
