package button_windows;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import person.Teacher;

public class TeacherFunctions {
	public void addTeacher(Stage addTeacherWindow) {
		AnchorPane root = new AnchorPane();
		addTeacherWindow.setTitle("Add Teacher");
		Scene addTeacherScene = new Scene(root, 400, 380);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox teacherID = new HBox();
		HBox fname = new HBox();
		HBox mname = new HBox();
		HBox lname = new HBox();
		HBox email = new HBox();
		HBox phone = new HBox();
		HBox qualification = new HBox();
		
		
		Label idLabel = new Label("Teacher ID : ");
		Label fnameLabel = new Label("First Name : ");
		Label mnameLabel = new Label("Middle Name : ");
		Label lnameLabel = new Label("Last Name : ");
		Label emailLabel = new Label("Email : ");
		Label phoneLabel = new Label("Phone : ");
		Label qualificationLabel = new Label("Qualification : ");
		
		TextField idField = new TextField();
		TextField fnameField = new TextField();
		TextField mnameField = new TextField();
		TextField lnameField = new TextField();
		TextField emailField = new TextField();
		TextField phoneField = new TextField();
		TextField qualificationField = new TextField();

		
		

		teacherID.getChildren().addAll(idLabel, idField);
		teacherID.setAlignment(Pos.CENTER);
		fname.getChildren().addAll(fnameLabel, fnameField);
		fname.setAlignment(Pos.CENTER);
		mname.getChildren().addAll(mnameLabel, mnameField);
		mname.setAlignment(Pos.CENTER);
		lname.getChildren().addAll(lnameLabel, lnameField);
		lname.setAlignment(Pos.CENTER);
		email.getChildren().addAll(emailLabel, emailField);
		email.setAlignment(Pos.CENTER);
		phone.getChildren().addAll(phoneLabel, phoneField);
		phone.setAlignment(Pos.CENTER);
		qualification.getChildren().addAll(qualificationLabel, qualificationField);
		qualification.setAlignment(Pos.CENTER);
		
		Button submit = new Button("Submit");

		
		contents.getChildren().addAll(teacherID, fname, mname, lname, email, phone, qualification, submit);
		contents.setSpacing(10);
		contents.setAlignment(Pos.BASELINE_CENTER);
		contents.setPadding(new Insets(20, 0, 0, 0));
		
		try {
		       Class.forName("com.mysql.cj.jdbc.Driver").newInstance();      
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school_system?user=root&password=pass123&useSSL=false&serverTimezone=GMT" );
			
		submit.setOnAction(e -> {
			Integer idInput = Integer.parseInt(idField.getText());
			String fnameInput = fnameField.getText();
			String mnameInput = mnameField.getText();
			String lnameInput = lnameField.getText();
			String emailInput = emailField.getText();
			Integer phoneInput = Integer.parseInt(phoneField.getText());
			String qualificationInput = qualificationField.getText();
		
			Teacher t = new Teacher(idInput, fnameInput, mnameInput, lnameInput, emailInput, phoneInput, qualificationInput);
		
			t.addTeacher(con);
			addTeacherWindow.close();
			
		});
		}
		catch(SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		border.setCenter(contents);
		border.prefWidthProperty().bind(addTeacherWindow.widthProperty());
		border.prefHeightProperty().bind(addTeacherWindow.heightProperty());
		root.getChildren().add(border);
		addTeacherWindow.setScene(addTeacherScene);
		addTeacherWindow.show();
	}
	
	
	public void changeQualification(Stage changeQWindow) {
		AnchorPane root = new AnchorPane();
		changeQWindow.setTitle("Change Qualification");
		Scene changeQScene = new Scene(root, 330, 150);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox layout = new HBox();
		
		Label label = new Label("Teacher ID : ");
		
		TextField id = new TextField();
		
		layout.getChildren().addAll(label, id);
		layout.setAlignment(Pos.CENTER);
		
		Button next = new Button("Next");
		
		contents.getChildren().addAll(layout, next);
		contents.setPadding(new Insets(30,0,0,0));
		contents.setSpacing(10);
		contents.setAlignment(Pos.BASELINE_CENTER);
		
		next.setOnAction(e -> {
			Integer idInput = Integer.parseInt(id.getText());

			Stage changeQSubmit = new Stage();
			changeQualificationSubmit(changeQSubmit, idInput);
			changeQWindow.close();
		});
		
		border.setCenter(contents);
		border.prefHeightProperty().bind(changeQWindow.heightProperty());
		border.prefWidthProperty().bind(changeQWindow.widthProperty());
		root.getChildren().add(border);
		changeQWindow.setScene(changeQScene);
		changeQWindow.show();
		
		
		
	}
	
	
	public void changeQualificationSubmit(Stage changeQSubmit, int id) {
		AnchorPane root = new AnchorPane();
		changeQSubmit.setTitle("Submit new Qualification");
		Scene submitScene = new Scene(root, 370, 150);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox layout = new HBox();
		
		Label label = new Label("New Qualification : ");
		
		TextField qInput = new TextField();
		
		layout.getChildren().addAll(label, qInput);
		layout.setAlignment(Pos.CENTER);
		
		Button submit = new Button("Submit");
		
		contents.getChildren().addAll(layout, submit);
		contents.setPadding(new Insets(30,0,0,0));
		contents.setSpacing(10);
		contents.setAlignment(Pos.BASELINE_CENTER);
		
		try {
		       Class.forName("com.mysql.cj.jdbc.Driver").newInstance();      
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school_system?user=root&password=pass123&useSSL=false&serverTimezone=GMT" );
		
		submit.setOnAction(e -> {
			Teacher t = new Teacher();
			
			String newQualification = qInput.getText();
			
			t.setQualification(con, newQualification, id);
			changeQSubmit.close();
		});
		}catch(SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		border.setCenter(contents);
		border.prefHeightProperty().bind(changeQSubmit.heightProperty());
		border.prefWidthProperty().bind(changeQSubmit.widthProperty());
		root.getChildren().add(border);
		changeQSubmit.setScene(submitScene);
		changeQSubmit.show();
		
		
		
	}
}
