package button_windows;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import person.Student;
import school.ClassGroup;
import school.ModuleGrade;

public class student_functions {
	
	public void startModules(Stage addStudentModules, Student s1) {
		AnchorPane anchor = new AnchorPane();
		addStudentModules.setTitle("Add Student Modules");
		Scene addStudentModulesScene = new Scene(anchor, 400, 380);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox m1 = new HBox();
		HBox m2 = new HBox();
		HBox m3 = new HBox();
		HBox m4 = new HBox();
		HBox m5 = new HBox();
		HBox m6 = new HBox();
		
		
		Label m1Label = new Label("Module 1 : ");
		Label m2Label = new Label("Module 2 : ");
		Label m3Label = new Label("Module 3 : ");
		Label m4Label = new Label("Module 4 : ");
		Label m5Label = new Label("Module 5 : ");
		Label m6Label = new Label("Module 6 : ");
		
		TextField m1Field = new TextField();
		TextField g1Field = new TextField();
		g1Field.setPrefWidth(50);
		
		TextField m2Field = new TextField();
		TextField g2Field = new TextField();
		g2Field.setPrefWidth(50);

		TextField m3Field = new TextField();
		TextField g3Field = new TextField();
		g3Field.setPrefWidth(50);

		TextField m4Field = new TextField();
		TextField g4Field = new TextField();
		g4Field.setPrefWidth(50);

		TextField m5Field = new TextField();
		TextField g5Field = new TextField();
		g5Field.setPrefWidth(50);

		TextField m6Field = new TextField();
		TextField g6Field = new TextField();
		g6Field.setPrefWidth(50);

		
		

		m1.getChildren().addAll(m1Label, m1Field, g1Field);
		
		m1.setAlignment(Pos.CENTER);
		m2.getChildren().addAll(m2Label, m2Field, g2Field);
		m2.setAlignment(Pos.CENTER);
		m3.getChildren().addAll(m3Label, m3Field, g3Field);
		m3.setAlignment(Pos.CENTER);
		m4.getChildren().addAll(m4Label, m4Field, g4Field);
		m4.setAlignment(Pos.CENTER);
		m5.getChildren().addAll(m5Label, m5Field, g5Field);
		m5.setAlignment(Pos.CENTER);
		m6.getChildren().addAll(m6Label, m6Field, g6Field);
		m6.setAlignment(Pos.CENTER);
		
		Button submit = new Button("Submit");


		
		try {
			
		       Class.forName("com.mysql.cj.jdbc.Driver").newInstance();      
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school_system?user=root&password=pass123&useSSL=false&serverTimezone=GMT" );
		       

		   //    s1.addModules(module1, module2, module3, module4, module5, module6, con);
		       
		       submit.setOnAction(e -> {
		   		String mod1 = m1Field.getText();
				Integer gra1 = Integer.parseInt(g1Field.getText());
				String mod2 = m2Field.getText();
				Integer gra2 = Integer.parseInt(g2Field.getText());
				String mod3 = m3Field.getText();
				Integer gra3 = Integer.parseInt(g3Field.getText());
				String mod4 = m4Field.getText();
				Integer gra4 = Integer.parseInt(g4Field.getText());
				String mod5 = m5Field.getText();
				Integer gra5 = Integer.parseInt(g5Field.getText());
				String mod6 = m6Field.getText();
				Integer gra6 = Integer.parseInt(g6Field.getText());
				
			       ModuleGrade module1 = new ModuleGrade(mod1, gra1);
			       ModuleGrade module2 = new ModuleGrade(mod2, gra2);
			       ModuleGrade module3 = new ModuleGrade(mod3, gra3);
			       ModuleGrade module4 = new ModuleGrade(mod4, gra4);
			       ModuleGrade module5 = new ModuleGrade(mod5, gra5);
			       ModuleGrade module6 = new ModuleGrade(mod6, gra6);
			       
		       ClassGroup cg = new ClassGroup();
		       cg.addStudent(s1, con);
		       s1.addModules(module1, module2, module3, module4, module5, module6, con);
		       addStudentModules.close();
		});
		}
		catch(SQLException e) {
			e.printStackTrace();
		} catch (InstantiationException e1) {
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		
		contents.getChildren().addAll(m1, m2, m3, m4, m5, m6, submit);
		contents.setAlignment(Pos.BASELINE_CENTER);
		contents.setPadding(new Insets(50, 0, 0, 0));
		contents.setSpacing(10);
		
		border.setCenter(contents);
		border.prefWidthProperty().bind(addStudentModules.widthProperty());
		border.prefHeightProperty().bind(addStudentModules.heightProperty());
		anchor.getChildren().add(border);
		addStudentModules.setScene(addStudentModulesScene);
		addStudentModules.show();
	}
	
	
	
	public void start(Stage addStudentWindow) {
		AnchorPane anchor = new AnchorPane();
		addStudentWindow.setTitle("Add Student");
		Scene addStudentScene = new Scene(anchor, 400, 380);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox studentID = new HBox();
		HBox fname = new HBox();
		HBox mname = new HBox();
		HBox lname = new HBox();
		HBox email = new HBox();
		HBox phone = new HBox();
		HBox dob = new HBox();
		
		Label studentIDLabel = new Label("Student ID : ");
		Label fnameLabel = new Label("First Name : ");
		Label mnameLabel = new Label("Middle Name : ");
		Label lnameLabel = new Label("Last Name : ");
		Label emailLabel = new Label("Email : ");
		Label phoneLabel = new Label("Phone : ");
		Label dobLabel = new Label("DOB : ");
		
		TextField idField = new TextField();
		TextField fnameField = new TextField();
		TextField mnameField = new TextField();
		TextField lnameField = new TextField();
		TextField emailField = new TextField();
		TextField phoneField = new TextField();
		TextField dobField = new TextField();
		
		studentID.getChildren().addAll(studentIDLabel, idField);
		studentID.setAlignment(Pos.CENTER);
		fname.getChildren().addAll(fnameLabel, fnameField);
		fname.setAlignment(Pos.CENTER);
		mname.getChildren().addAll(mnameLabel, mnameField);
		mname.setAlignment(Pos.CENTER);
		lname.getChildren().addAll(lnameLabel, lnameField);
		lname.setAlignment(Pos.CENTER);
		email.getChildren().addAll(emailLabel, emailField);
		email.setAlignment(Pos.CENTER);
		phone.getChildren().addAll(phoneLabel, phoneField);
		phone.setAlignment(Pos.CENTER);
		dob.getChildren().addAll(dobLabel, dobField);
		dob.setAlignment(Pos.CENTER);
		
		Button next = new Button("Next");

		
		contents.getChildren().addAll(studentID, fname, mname, lname, email, phone, dob, next);
		contents.setAlignment(Pos.BASELINE_CENTER);
		contents.setPadding(new Insets(20, 0, 0, 0));
		contents.setSpacing(10);
		
		next.setOnAction(e -> {
			Integer id = Integer.parseInt(idField.getText());
			String getFname = fnameField.getText();
			String getMname = mnameField.getText();
			String getLname = lnameField.getText();
			String getEmail = emailField.getText();
			Integer getPhone = Integer.parseInt(phoneField.getText());
			String getClass = dobField.getText();
			
			Student s = new Student(id, getFname, getMname, getLname, getEmail, getPhone, getClass);
			
			
			
			Stage addStudentModulesScene = new Stage();
			startModules(addStudentModulesScene, s);
		       addStudentWindow.close();

		});
		
		
		
		border.setCenter(contents);
		border.prefWidthProperty().bind(addStudentWindow.widthProperty());
		border.prefHeightProperty().bind(addStudentWindow.heightProperty());
		anchor.getChildren().add(border);
		addStudentWindow.setScene(addStudentScene);
		addStudentWindow.show();
		
	}
	
	
	
	public void removeStudent(Stage remove) {
		remove.setTitle("Remove Student");
		AnchorPane root = new AnchorPane();
		Scene removeStudentScene = new Scene(root, 330, 150);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox layout = new HBox();
		
		TextField input = new TextField();
		Label studentID = new Label("Student ID : ");
		Button submit = new Button("Submit");
		
		layout.getChildren().addAll(studentID, input);
		contents.getChildren().addAll(layout, submit);
		
		contents.setAlignment(Pos.BASELINE_CENTER);
		contents.setPadding(new Insets(30, 0, 0, 30));
		contents.setSpacing(10);
		try {
		       Class.forName("com.mysql.cj.jdbc.Driver").newInstance();      
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school_system?user=root&password=pass123&useSSL=false&serverTimezone=GMT" );
				submit.setOnAction(e -> {
					Integer id = Integer.parseInt(input.getText());
					
					ClassGroup cg = new ClassGroup();
					cg.removeStudent(id, con);
					remove.close();
				});
		
		}catch(SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		border.setCenter(contents);
		border.prefWidthProperty().bind(remove.widthProperty());
		border.prefHeightProperty().bind(remove.heightProperty());
		root.getChildren().add(border);
		remove.setScene(removeStudentScene);
		remove.show();
		
	}



	public void changeGrade(Stage changeGWindow) {
		AnchorPane root = new AnchorPane();
		changeGWindow.setTitle("Modify Grade");
		Scene changeGScene = new Scene(root, 330, 150);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox layout = new HBox();
		
		Label label = new Label("Student ID : ");
		TextField field = new TextField();
		
		Button next = new Button("Next");

		       next.setOnAction(e -> {
		    	   Integer idInput = Integer.parseInt(field.getText());
		    	   Stage changeGInput = new Stage();
		    	   changeGradeInput(idInput, changeGInput);
		    	   changeGWindow.close();
			});
		
		layout.getChildren().addAll(label, field);
		contents.getChildren().addAll(layout, next);
		contents.setAlignment(Pos.BASELINE_CENTER);
		contents.setPadding(new Insets(30,0,0,30));
		contents.setSpacing(10);
		
		border.setCenter(contents);
		border.prefHeightProperty().bind(changeGWindow.heightProperty());
		border.prefWidthProperty().bind(changeGWindow.widthProperty());
		root.getChildren().add(border);
		changeGWindow.setScene(changeGScene);
		changeGWindow.show();
	}
	
	
	public void changeGradeInput(int id, Stage changeGStage) {
		AnchorPane root = new AnchorPane();
		changeGStage.setTitle("Change Grade");
		Scene changeGScene = new Scene(root, 330, 150);
		BorderPane border = new BorderPane();
		
		VBox contents = new VBox();
		
		HBox layout = new HBox();
		
		Label label = new Label("Module\t\tGrade");
		
		TextField module = new TextField();
		TextField grade = new TextField();
		grade.setPrefWidth(50);
		
		layout.getChildren().addAll(module, grade);
		
		Button submit = new Button("Submit");
		try {
			
		       Class.forName("com.mysql.cj.jdbc.Driver").newInstance();      
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school_system?user=root&password=pass123&useSSL=false&serverTimezone=GMT" );
			submit.setOnAction(e -> {
				String moduleInput = module.getText();
				Integer gradeInput = Integer.parseInt(grade.getText());
				
				ModuleGrade mg = new ModuleGrade(moduleInput);
				Student s = new Student();
				
				s.changeModule(mg, gradeInput, con, id);
				changeGStage.close();
			});
		}
		catch(SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		contents.getChildren().addAll(label, layout, submit);
		contents.setAlignment(Pos.BASELINE_CENTER);
		contents.setPadding(new Insets(20,0,0,25));
		contents.setSpacing(10);
		
		border.setCenter(contents);
		border.prefHeightProperty().bind(changeGStage.heightProperty());
		border.prefWidthProperty().bind(changeGStage.widthProperty());
		root.getChildren().add(border);
		changeGStage.setScene(changeGScene);
		changeGStage.show();
		
		
		
	}
}
