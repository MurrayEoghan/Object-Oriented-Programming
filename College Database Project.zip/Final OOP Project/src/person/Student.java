package person;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javafx.scene.control.TextArea;
import school.*;
public class Student extends Person{
	private static ArrayList<ModuleGrade> mg = new ArrayList<ModuleGrade>();
	private String dob;
	private int noModules = 0;
	private int studentID;
	
	public Student() {
	}
	
	public Student(int id, String fname, String mname, String lname, String email, int phone, String dob) {
		setfName(fname);
		setmName(mname);
		setlName(lname);
		setEmail(email);
		setPhone(phone);
		this.dob = dob;
		this.studentID = id;
	}
	
	public Student(int id, String fname, String lname, String email, int phone, String dob) {
		setfName(fname);
		setlName(lname);
		setEmail(email);
		setPhone(phone);
		this.dob = dob;
		this.studentID = id;
	}
	
	public Student(String fname, String lname, String email, int phone, String dob) {
		setfName(fname);
		setlName(lname);
		setEmail(email);
		setPhone(phone);
		this.dob = dob;
	}
	
	
	public void addModules(ModuleGrade m1, ModuleGrade m2, ModuleGrade m3, ModuleGrade m4, ModuleGrade m5, ModuleGrade m6, Connection con) {
		String query = "Insert into grades (StudentID, M1, M2, M3, M4, M5, M6)"+" values (?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement add = con.prepareStatement(query);
			add.setInt(1, studentID);
			add.setString(2, m1.getModule()+" "+m1.getGrade());
			add.setString(3, m2.getModule()+" "+m2.getGrade());
			add.setString(4, m3.getModule()+" "+m3.getGrade());
			add.setString(5, m4.getModule()+" "+m4.getGrade());
			add.setString(6, m5.getModule()+" "+m5.getGrade());
			add.setString(7, m6.getModule()+" "+m6.getGrade());
			add.execute();


		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public void changeModule(ModuleGrade moduleG, int Grade, Connection con, int id) {
		int prevGrade = moduleG.getGrade();
		moduleG.setGrade(Grade);
		
		try {
			Statement stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("SELECT * FROM grades WHERE StudentID = "+id+";"); 
			while(res.next()) {
				String m1 = res.getString(2);
				String m2 = res.getString(3);
				String m3 = res.getString(4);
				String m4 = res.getString(5);
				String m5 = res.getString(6);
				String m6 = res.getString(7);
				
				if(m1.contains(moduleG.getModule())) {
					String query = "UPDATE grades SET M1 = ? WHERE StudentID = ?";
					PreparedStatement change = con.prepareStatement(query);
					change.setString(1, moduleG.getModule()+" "+moduleG.getGrade());
					change.setInt(2, id);
					change.execute();
					System.out.println("Grade changed to "+Grade+"\n");

				}
				else if(m2.contains(moduleG.getModule())){
					String query = "UPDATE grades SET M2 = ? WHERE StudentID = ?";
					PreparedStatement change = con.prepareStatement(query);
					change.setString(1, moduleG.getModule()+" "+moduleG.getGrade());
					change.setInt(2, id);
					change.execute();
					System.out.println("Grade changed from "+prevGrade+" to "+Grade+"\n");
				}
				else if(m3.contains(moduleG.getModule())){
					String query = "UPDATE grades SET M3 = ? WHERE StudentID = ?";
					PreparedStatement change = con.prepareStatement(query);
					change.setString(1, moduleG.getModule()+" "+moduleG.getGrade());
					change.setInt(2, id);
					change.execute();
					System.out.println("Grade changed from "+prevGrade+" to "+Grade+"\n");
				}
				else if(m4.contains(moduleG.getModule())){
					String query = "UPDATE grades SET M4 = ? WHERE StudentID = ?";
					PreparedStatement change = con.prepareStatement(query);
					change.setString(1, moduleG.getModule()+" "+moduleG.getGrade());
					change.setInt(2, id);
					change.execute();
					System.out.println("Grade changed from "+prevGrade+" to "+Grade+"\n");
				}
				else if(m5.contains(moduleG.getModule())){
					String query = "UPDATE grades SET M5 = ? WHERE StudentID = ?";
					PreparedStatement change = con.prepareStatement(query);
					change.setString(1, moduleG.getModule()+" "+moduleG.getGrade());
					change.setInt(2, id);
					change.execute();
					System.out.println("Grade changed from "+prevGrade+" to "+Grade+"\n");
				}
				else if(m6.contains(moduleG.getModule())){
					String query = "UPDATE grades SET M6 = ? WHERE StudentID = ?";
					PreparedStatement change = con.prepareStatement(query);
					change.setString(1, moduleG.getModule()+" "+moduleG.getGrade());
					change.setInt(2, id);
					change.execute();
					System.out.println("Grade changed from "+prevGrade+" to "+Grade+"\n");
				}
				else {
					System.out.println("Module Doesnt exist.");
				}
			}
		}
		catch(SQLException e){
			e.printStackTrace();
			
		}
		
		
	}
	
	public void printMG(Connection con, TextArea ta) {
		String val = " ";
		try {
		Statement stmt = con.createStatement();
		ResultSet res2 = stmt.executeQuery("Select * From grades order by StudentID;");
		
		while(res2.next()) {
			int id = res2.getInt("StudentID");
			String m1 = res2.getString("M1");
			String m2 = res2.getString("M2");
			String m3 = res2.getString("M3");
			String m4 = res2.getString("M4");
			String m5 = res2.getString("M5");
			String m6 = res2.getString("M6");
			//System.out.println(" ID :  "+id+" | "+m1 +" | "+ m2 +" | "+ m3 + " | "+ m4 +" | "+ m5 + " | " + m6);
			val = " ID :  "+id+" \n "+m1 +" \n "+ m2 +" \n "+ m3 + " \n "+ m4 +" \n "+ m5 + " \n " + m6+"\n\n ";
			ta.appendText(val);
		}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public static ArrayList<ModuleGrade> getMg() {
		return mg;
	}

	public static void setMg(ArrayList<ModuleGrade> mg) {
		Student.mg = mg;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getNoModules() {
		return noModules;
	}

	public void setNoModules(int noModules) {
		this.noModules = noModules;
	}

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	@Override
	public String toString() {
		return getStudentID()+" "+getfName()+" "+getmName()+" "+getlName()+" "+getEmail()+" "+getPhone()+" "+getMg()+" ";
	}
	
}
