package person;

public class Person extends Name{
	private String email;
	private int phone;
	
	public Person() {
	}
	
	public Person(String email, int phone) {
		this.email = email;
		this.phone = phone;
	}
	
	public Person(String fname, String email, int phone) {
		setfName(fname);
		this.email = email;
		this.phone = phone;
	}
	
	public Person(String fname, String lname, String email, int phone) {
		setfName(fname);
		setlName(lname);
		this.email = email;
		this.phone = phone;
	}
	
	public Person(String fname, String mname, String lname, String email, int phone) {
		setfName(fname);
		setmName(mname);
		setlName(lname);
		this.email = email;
		this.phone = phone;
	}

	@Override
	public String toString() {
		return getfName()+" "+getmName()+" "+getlName()+" "+email+" "+phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}
}
